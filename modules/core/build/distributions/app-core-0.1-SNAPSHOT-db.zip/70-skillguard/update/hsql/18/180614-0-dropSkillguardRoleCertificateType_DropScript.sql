drop table SKILLGUARD_ROLE_CERTIFICATE_TYPE__UNUSED if exists cascade ;
