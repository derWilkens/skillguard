drop table SKILLGUARD_ROLE__UNUSED if exists cascade ;
