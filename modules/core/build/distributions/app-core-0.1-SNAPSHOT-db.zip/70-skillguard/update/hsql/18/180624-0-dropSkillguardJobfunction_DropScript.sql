drop table SKILLGUARD_JOBFUNCTION__UNUSED if exists cascade ;
