drop table SKILLGUARD_DEPARTMENT__UNUSED if exists cascade ;
