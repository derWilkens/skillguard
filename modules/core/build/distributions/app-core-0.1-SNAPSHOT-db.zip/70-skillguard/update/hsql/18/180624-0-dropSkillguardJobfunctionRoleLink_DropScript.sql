drop table SKILLGUARD_JOBFUNCTION_ROLE_LINK__UNUSED if exists cascade ;
