alter table SEC_USER add column DEPARTMENT_ID varchar(36) ;
alter table SEC_USER add column DTYPE varchar(100) ;
