update SEC_USER set DTYPE = 'sec$User' where DTYPE is null ;
