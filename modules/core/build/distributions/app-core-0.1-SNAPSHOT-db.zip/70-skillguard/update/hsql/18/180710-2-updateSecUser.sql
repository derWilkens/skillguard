alter table SEC_USER add column JOBFUNCTION_ID varchar(36) ;
