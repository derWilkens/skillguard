drop table SKILLGUARD_CERTIFICATE_TYPE__UNUSED if exists cascade ;
